package project.service;

public class Constants {
    public static String ADMIN = "ADMIN";

    public static String CUSTOMER = "CUSTOMER";

    public static String EMPLOYEE = "EMPLOYEE";

    public static String CASHIER = "CASHIER";

    public static String SIMPLE = "SIMPLE";

    public static String MANAGER = "MANAGER";

    public static String ACTIVE = "ACTIVE";

    public static String PENDING = "PENDING";

    public static String CANCELLED = "CANCELLED";

    public static String COMPLETED = "COMPLETED";

    public static String CREATED = "CREATED";

    public static String CHARGED = "CHARGED";



}

package project.service.statistics;

public interface PDFService {
    byte[] getStatisticsPDF();
}

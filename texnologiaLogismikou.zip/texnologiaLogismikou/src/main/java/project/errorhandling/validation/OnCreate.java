package project.errorhandling.validation;

import javax.validation.groups.Default;

public interface OnCreate extends Default {
}